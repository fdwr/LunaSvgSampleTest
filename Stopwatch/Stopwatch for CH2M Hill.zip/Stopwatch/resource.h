//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Stopwatch.rc
//
#define IddMain                         1
#define IdiMain                         1
#define IDRESET                         3
#define IDI_ICON1                       102
#define IdbPayDay                       103
#define IdcCounterLimitMonths           1000
#define IdcCounterLimitWeeks            1001
#define IdcCounterLimitDays             1002
#define IdcCounterLimitHours            1003
#define IdcMinutesPerDay                1004
#define IdcMonths                       1005
#define IdcWeeks                        1006
#define IdcDays                         1007
#define IdcHours                        1008
#define IdcTotalMonths                  1009
#define IdcTotalWeeks                   1010
#define IdcTotalDays                    1011
#define IdcTotalHours                   1012
#define IdcWrapMonths                   1013
#define IdcCounterWrapMonths            1013
#define IdcWrapWeeks                    1014
#define IdcCounterWrapWeeks             1014
#define IdcWrapDays                     1015
#define IdcCounterWrapDays              1015
#define IdcWrapHours                    1016
#define IdcCounterWrapHours             1016
#define IdcCalendar                     1017
#define IdcCounterLabel                 1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
