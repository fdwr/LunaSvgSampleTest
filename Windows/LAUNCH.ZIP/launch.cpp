// launch.cpp : Simply launches the given file.

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <tchar.h>
#include "shellapi.h"

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	if (lstrlen(lpCmdLine) <= 0) {
		MessageBox(
			NULL,
			TEXT("No file was given to launch. It needs a parameter after the executable name."),
			TEXT("Simple Launch File"),
			MB_OK|MB_ICONINFORMATION
			);
		return (int) 2;
	}

	if ( (int)ShellExecute(NULL, TEXT("open"), lpCmdLine, NULL, TEXT("."), SW_MAXIMIZE) < 32) {
		LPVOID lpMsgBuf;
		TCHAR launchPath[256];
		 
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);

		// Display the string.
		wsprintf(launchPath, "Failed to launch %s", lpCmdLine);
		MessageBox( NULL, (LPCSTR)lpMsgBuf, launchPath, MB_OK|MB_ICONINFORMATION );

		// Free the buffer.
		LocalFree( lpMsgBuf );
		return (int) 1;
	}

	return (int) 0;
}
